import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { Login } from '../login';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
empById:Employee[]=[];
employeeDetailsFlag:boolean=false;
empId:number;
userName:string;
logObj:Login;
emp:Employee;
  constructor(public service:EmployeeService,public app:AppComponent,private router:Router) { 
    this.userName=this.app.userName;
this.logObj=this.service.loginArr.find(login=>login.userName===this.userName);
console.log(this.logObj);
this.empId=this.logObj.empId;

    
    this.empDetails();

  }

  ngOnInit(): void {
  }
  empDetails()
  {
  
    this.empById.splice(0,this.empById.length)
  
  this.emp=this.service.empArr.find(e=>e.empId===this.empId)
  this.empById.push(this.emp);
  this.employeeDetailsFlag=true;
  }
  back()
  {
    this.employeeDetailsFlag=false;
    this.router.navigate(['/employee']);
  }
}
