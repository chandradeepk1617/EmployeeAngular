import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-by-id',
  templateUrl: './search-by-id.component.html',
  styleUrls: ['./search-by-id.component.css']
})
export class SearchByIdComponent implements OnInit {
Id:Number;
searchIdFlag:boolean=false;
empById:Employee[]=[];
errorFlag:boolean=false;
  constructor(public service:EmployeeService,private router:Router) { }

  ngOnInit(): void {
  }

  searchId()
  {
    console.log(this.Id);
    let emp1:Employee=null;
    this.empById.splice(0,this.empById.length)
   
    
    
    for(let emp of this.service.empArr)
    {
      if(emp.empId===this.Id)
      {
    //emp1=this.service.empArr.find(e=>e.empId===this.Id);
  emp1=emp;
    this.empById.push(emp1);
    this.errorFlag=false;
    this.searchIdFlag=true;
    }

  }
  if(emp1===null)
  {
this.errorFlag=true;
this.searchIdFlag=false;
  }
}
  back()
  {
    this.searchIdFlag=false;
    this.errorFlag=false;
    this.router.navigate(['/employee']);
  }
  back1()
  {
    this.errorFlag=false;
  }
  
}
