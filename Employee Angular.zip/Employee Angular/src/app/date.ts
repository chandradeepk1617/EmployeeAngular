export class DateValidation {
  
    dateTo: Date;
    dateFrom: Date;
    reason:string;
  }
  
  