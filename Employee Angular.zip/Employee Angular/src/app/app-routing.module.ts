import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { ManagerComponent } from './manager/manager.component';
import { EmployeeComponent } from './employee/employee.component';
import { SearchByIdComponent } from './search-by-id/search-by-id.component';
import { SearchByNameComponent } from './search-by-name/search-by-name.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { CancelLeaveComponent } from './cancel-leave/cancel-leave.component';
import { EditLeaveComponent } from './edit-leave/edit-leave.component';
import { AppliedLeavesComponent } from './applied-leaves/applied-leaves.component';
import { ChangePasswordComponent } from './change-password/change-password.component';


const routes: Routes = [
  {path:'admin', component:AdminComponent},
  {path:'manager',component:ManagerComponent},
  {path:'employee',component:EmployeeComponent, children:[
    {path:'',component:EmployeeDetailsComponent},
    {path:'searchId',component:SearchByIdComponent},
    {path:'searchName',component:SearchByNameComponent},
    {path:'empDetails',component:EmployeeDetailsComponent},
    {path:'applyLeave',component:ApplyLeaveComponent},
    {path:'cancelLeave',component:CancelLeaveComponent},
    {path:'editLeave',component:EditLeaveComponent},
    {path:'appliedLeave',component:AppliedLeavesComponent},
    {path:'changePassword',component:ChangePasswordComponent},
    { path:'**', redirectTo: '/employee', pathMatch: 'full'}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
