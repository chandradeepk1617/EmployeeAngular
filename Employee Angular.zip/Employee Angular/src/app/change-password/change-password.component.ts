import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
logObj:Login=null;
userName:string;
oldPassword:string;
newPassword:string;
confirmPassword:string;
index:number;
oldPasswordFlag=false;
newPasswordFlag=false;
successFlag=false;
  constructor(public service:EmployeeService,public app:AppComponent,public router:Router) {
this.userName=this.app.userName;
let count=0;    
for(let login of this.service.loginArr)
{
  if(login.userName===this.userName)
  {
    this.logObj=login;
    this.index=count;
  }
count++;
}
   }

  ngOnInit(): void {
  }
changePassword()
{
  console.log(this.logObj.password)
  if(this.oldPassword===this.logObj.password)
  {
    if(this.newPassword===this.confirmPassword)
    {
      this.logObj.password=this.newPassword;
this.service.changePassword(this.index,this.logObj);
this.successFlag=true;
    }
    else{
      this.newPasswordFlag=true;
    }
  }
  else
  {
    this.oldPasswordFlag=true;
  }
}
close()
{
  this.successFlag=false;
  this.oldPasswordFlag=false;
  this.newPasswordFlag=false;
}
back()
{
  this.successFlag=false;
  this.oldPasswordFlag=false;
  this.newPasswordFlag=false;
  this.router.navigate(['/employee']);
}
}
