import { Component, OnInit,Input} from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { ActivatedRoute, Router } from '@angular/router';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Leave } from '../leave';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
// searchByIdFlag:boolean=false;
// searchByNameFlag:boolean=false;
// searchIdFlag:boolean=false;
// searchNameFlag:boolean=false;
// AppliedLeaveFlag:boolean=false;
// name:string;
// Id:number;
// empById:Employee[]=[];
// leaveArr1:Leave[]=[];
// userName:string;
// logObj:Login;
// empId:number;
// employeeDetailsFlag:boolean=false;
userName:string;

  constructor(public service:EmployeeService,private route:Router,public app:AppComponent) { 
    this.userName=this.app.userName;
// this.userName=this.app.userName;
// this.logObj=this.service.loginArr.find(login=>login.userName===this.userName);
// console.log(this.logObj);
// this.empId=this.logObj.empId;
  }

  ngOnInit(): void {
  }
// searchById()
// {
//   this.searchByIdFlag=true;
//   this.searchByNameFlag=false;
//   this.searchIdFlag=false;
//   this.employeeDetailsFlag=false;
//  this.AppliedLeaveFlag=false;
// }
// searchId()
// {
//   console.log(this.Id);
//   let emp1:Employee;
//   this.empById.splice(0,this.empById.length)
//   this.searchByIdFlag=false;
//   this.searchByNameFlag=false;
//   this.searchIdFlag=true;
//   this.employeeDetailsFlag=false;
//   this.AppliedLeaveFlag=false;
//   emp1=this.service.empArr.find(e=>e.empId===this.Id);

//   this.empById.push(emp1);
// }
// searchByName()
// {
//   this.searchByIdFlag=false;
//   this.searchByNameFlag=true;
//   this.searchIdFlag=false;
//   this.searchNameFlag=false;
//   this.employeeDetailsFlag=false;
//   this.AppliedLeaveFlag=false;
// }
// searchName()
// {
//   this.empById.splice(0,this.empById.length)
//   let emp:Employee;
//   this.searchByIdFlag=false;
//   this.searchByNameFlag=false;
//   this.searchIdFlag=false;
//   this.searchNameFlag=true;
//   this.employeeDetailsFlag=false;
//   this.AppliedLeaveFlag=false;
//   emp=this.service.empArr.find(e=>e.empName===this.name)
//   this.empById.push(emp);

// }
// back()
// {
//   this.searchByIdFlag=false;
//   this.searchByNameFlag=false;
//   this.searchIdFlag=false;
//   this.searchNameFlag=false; 
//   this.employeeDetailsFlag=false;
//   this.AppliedLeaveFlag=false;
// }
// empDetails()
// {

//   this.empById.splice(0,this.empById.length)
// let emp:Employee;
// emp=this.service.empArr.find(e=>e.empId===this.empId)
// this.empById.push(emp);
// this.employeeDetailsFlag=true;
// }
// searchLeaves()
// {
//   this.searchByIdFlag=false;
//   this.searchByNameFlag=false;
//   this.searchIdFlag=false;
//   this.searchNameFlag=false; 
//   this.employeeDetailsFlag=false;
//   this.AppliedLeaveFlag=true;
// for(let leave of this.service.leaveArr)
// {
// if(leave.empId===this.empId)
// {
// this.leaveArr1.push(leave);
// }
// }
// }
logout()
{
  this.app.loginFlag=false;
  this.app.userName="";
  this.app.password="";
  this.route.navigate(['/..']);
}
}
