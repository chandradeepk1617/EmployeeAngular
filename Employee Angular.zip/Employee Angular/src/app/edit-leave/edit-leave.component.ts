import { Component, OnInit } from '@angular/core';
import { Login } from '../login';
import { Leave } from '../leave';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';
import { DateValidation } from '../date';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-edit-leave',
  templateUrl: './edit-leave.component.html',
  styleUrls: ['./edit-leave.component.css']
})
export class EditLeaveComponent implements OnInit {
   index=0;
  id:number;
  AppliedLeaveFlag:boolean=false;
  logObj:Login
  leaveArr1:Leave[]=[];
  leaveArr2:Leave[]=[];
  empId:number;
  userName:string;
  errorFlag:boolean=false;
  successFlag=false;
  errorflag1=false;
  successFlag1=false;
  fromDate:Date;
  toDate:Date;
  appliedDate:Date=new Date();
  dateFlag=false;
  reason:string;
  leaveObj:Leave;
  form:FormGroup;
  date:string=this.appliedDate.toISOString().slice(0,10);
  addFlag=false;
    constructor(public service:EmployeeService,public app:AppComponent,private router:Router,public fb:FormBuilder) { 
  
      this.userName=this.app.userName;
  this.logObj=this.service.loginArr.find(login=>login.userName===this.userName);
  console.log(this.logObj);
  this.empId=this.logObj.empId;
  this.searchLeaves();
  this.createForm();
    }
  
    ngOnInit(): void {
  
  
    }
    createForm() {
      this.form = this.fb.group({
        dateTo: ['', Validators.required ],
        dateFrom: ['', Validators.required ],
        reason:['',Validators.required]
      }, {validator: this.dateLessThan('dateFrom', 'dateTo')});
    }
    
    dateLessThan(from: string, to: string) {
      return (group: FormGroup): {[key: string]: any} => {
        let f = group.controls[from];
        let t = group.controls[to];
        if ((f.value >= t.value)||(f.value<this.appliedDate) ){
          return {
            dates: "Date from should be less than Date to"
          };
        }
        return {};
      }
  }
  onSubmit()
  {
  this.add(this.form.value)
  }
  
  add(req1:DateValidation)
  {
    let tdate=new Date(req1.dateFrom);
   if(this.appliedDate>tdate)
   {
     this.dateFlag=true;
   }
   else
   {
    this.fromDate=req1.dateFrom;
    this.toDate=req1.dateTo;
    this.reason=req1.reason;
  this.leaveObj.fromDate=this.fromDate;
  this.leaveObj.toDate=this.toDate;
  this.leaveObj.reason=this.reason;
  this.leaveObj.appliedDate=this.date;
  this.service.edit(this.leaveObj,this.index);
  this.leaveArr2.push(this.leaveObj);
  this.addFlag=true;
  }
  }
    searchLeaves()
    {
    let count=0;
    let status='pending';  
    for(let leave of this.service.leaveArr)
    {
    if(leave.empId===this.empId)
    {
      if(leave.status===status)
      {
        this.leaveArr1.push(leave);
        count=count+1;
        
      }
      else
      {
   
    }
  }
    }
    if(count===0)
    {
      this.errorFlag=true;
    }
    else
    {
      this.AppliedLeaveFlag=true;
    }
    }
    close()
    {
      this.errorflag1=false;
      this.errorFlag=false;
      this.AppliedLeaveFlag=false;
      this.successFlag=false;
      this.router.navigate(['/employee']);
    }
    home()
    {
      this.errorflag1=false;
      this.errorFlag=false;
      this.AppliedLeaveFlag=false;
      this.successFlag=false;
      this.router.navigate(['/employee']);
      
    }
    close1()
    {
  
      this.errorflag1=false;
      this.errorFlag=false;
      this.AppliedLeaveFlag=true;
      this.successFlag=false;
    }
    edit()
  {
    let count=0;
    
    let index1=0;
    this.index=0;
    for(let leave of this.service.leaveArr)
    {
      console.log(this.id);

      if(leave.leaveId===this.id)
      {
        this.index=count;
        index1++;
        this.leaveObj=leave;
        
      }
      count=count+1;
    }
    if(index1===0)
    {
      this.errorflag1=true;
    }
    else
    {
    
      this.successFlag1=true;
      this.AppliedLeaveFlag=false;
    }
  }
  back()
  {
    this.dateFlag=false;
  }
}
