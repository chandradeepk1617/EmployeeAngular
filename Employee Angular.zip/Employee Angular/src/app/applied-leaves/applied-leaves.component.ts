import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { AppComponent } from '../app.component';
import { Login } from '../login';
import { Leave } from '../leave';
import { Router } from '@angular/router';

@Component({
  selector: 'app-applied-leaves',
  templateUrl: './applied-leaves.component.html',
  styleUrls: ['./applied-leaves.component.css']
})
export class AppliedLeavesComponent implements OnInit {
AppliedLeaveFlag:boolean=false;
logObj:Login;
leaveArr1:Leave[]=[];
empId:number;
userName:string;
errorFlag:boolean=false;

  constructor(public service:EmployeeService,public app:AppComponent,private router:Router) { 

    this.userName=this.app.userName;
this.logObj=this.service.loginArr.find(login=>login.userName===this.userName);
console.log(this.logObj);
this.empId=this.logObj.empId;
this.searchLeaves();
  }

  ngOnInit(): void {


  }
  searchLeaves()
  {
  let count=0;
    
  for(let leave of this.service.leaveArr)
  {
  if(leave.empId===this.empId)
  {
  this.leaveArr1.push(leave);
  count=count+1;
  }
  }
  if(count===0)
  {
    this.errorFlag=true;
  }
  else
  {
    this.AppliedLeaveFlag=true;
  }
  }
  back()
  {
    this.AppliedLeaveFlag=false;
    this.router.navigate(['/employee']);
  }
  back1()
  {
this.errorFlag=false;
  }
  editLeave()
  {
this.router.navigate(['/..']);
  }
  cancelLeave()
  {
this.router.navigate(['/.cancelLeave']);
  }
}
