import { Injectable } from '@angular/core';
import { Login } from './login';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './Employee';
import { Leave } from './leave';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  public empArr:Employee[]=[];
  public loginArr:Login[]=[];
  public leaveArr:Leave[]=[];

  public url:string='./assets/login.json';
  public url1:string='./assets/employee.json';
public url2:string='./assets/login.json';
public url3:string='./assets/leave.json';
  constructor(private http:HttpClient) { 
    this.getEmployeeDetails();
    this.getLoginDetails1();
    this.getLeaveDetails();
  }
  public getLoginDetails():Observable<Login[]>
  {
    return this.http.get<Login[]>(this.url);
  }
  public getEmployeeDetails()
  {
this.http.get<Employee[]>(this.url1).subscribe(data=>this.empArr=data)
  }
  public getLoginDetails1()
  {
    this.http.get<Login[]>(this.url2).subscribe(data=>this.loginArr=data)

  }
  public getLeaveDetails()
  {
    this.http.get<Leave[]>(this.url3).subscribe(data=>this.leaveArr=data)
  }
  public changePassword(index:number,logObj:Login)
  {
this.loginArr[index]=logObj;

  }
  public add(leave:Leave)
  {
    this.leaveArr.push(leave);
  }
  public cancel(index:number)
  {
    this.leaveArr.splice(index,1);
  }
  public edit(leave:Leave,index:number)
  {
    this.leaveArr[index]=leave;
  }
}
