import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search-by-name',
  templateUrl: './search-by-name.component.html',
  styleUrls: ['./search-by-name.component.css']
})
export class SearchByNameComponent implements OnInit {
empById:Employee[]=[];
searchNameFlag:boolean=false;
name:string;
errorFlag:boolean=false;

  constructor(public service:EmployeeService,private router:Router) { }

  ngOnInit(): void {
  }
  searchName()
  {
    this.empById.splice(0,this.empById.length)
    let emp:Employee=null;
for(let emp1 of this.service.empArr)
{
if(emp1.empName===this.name)
{
  emp=emp1;
  this.empById.push(emp);
  this.searchNameFlag=true;
}
}
if(emp===null)
{
  this.searchNameFlag=false;
  this.errorFlag=true;
}
    
    //emp=this.service.empArr.find(e=>e.empName===this.name)
    
  

  }
  back()
  {
    this.searchNameFlag=false;
    this.router.navigate(['/employee']);

  }
  back1()
  {
this.errorFlag=false;
  }
  
}
